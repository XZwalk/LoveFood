//
//  AppDelegate.h
//  WTSDWebImageDemo
//
//  Created by ZZWangtao on 14-12-12.
//  Copyright (c) 2014年 ZZWangtao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

